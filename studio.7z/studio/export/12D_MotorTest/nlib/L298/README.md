# nBlocks_L298

n-Blocks Studio node to drive a DC motor with one bridge on L298  

## Parameters

* L298 IN1:       GPO pin 
* L298 IN2:       GPO pin   
* L298 Enable     PWM pin  

## Input Values:

Value: integer 
* 0 STOP
* 1 RIGHT
* 2 LEFT
* 3 BRAKE